<!-- Thái Sale đây :v
XÓA DÒNG NÀY LÀM CON CHÓ :))
GHI NGUỒN HỘ BỐ M :))
Fb.com/SayHiThaiNe
-->
<center><h style="color:white;"></h>
<a href="https://facebook.com/100010067132638" style="color:red;"></a></center><div style='text-align: right;position: fixed;z-index:9999999;bottom: 0; width: 100%;cursor: pointer;line-height: 0;display:block !important;'></div></body></html>
<style>	body {padding-bottom: 20px;} </style>