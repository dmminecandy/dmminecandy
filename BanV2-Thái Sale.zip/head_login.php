<?php
ob_start();
session_start();
date_default_timezone_set("Asia/Ho_Chi_Minh");
include 'config.php';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="content-type" content="text/html; UTF-8" />
    <title>BẢN FAKE BÁN HOTMAIL - TOKEN - VÕ DUY THÁI</title>
   
	<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet" />
 <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- /Meta -->
    <!-- SEO Meta -->
    <meta name="author" content="Hotmail giá rẻ">
    <meta name="keywords" content="bán hotmail cổ">
    <meta name="description" content="Bán Token & Clone">
    <!-- /SEO Meta -->
    <!-- OpenGraph meta -->
    <meta property="og:image" content="icon-180x180.png">
    <meta property="og:title" content="Bán hotmail cổ">
    <meta property="og:description" content="Hotmail cổ">
    <!-- /OpenGraph meta -->
    <!-- Favicon -->
    <link rel="shortcut icon" href="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSHOEgGqgI3fA21vilq5gvsHDdFbg17uW2HWJNOZZhlb4ho_1RR">
    <!-- /Favicon -->
     <!-- Styles -->
        <link rel="stylesheet" href="/thaisalecss/bootstrap.min.css">
    <link rel="stylesheet" href="/thaisalecss/bootstrap-theme.min.css">
    <link rel="stylesheet" href="/thaisalecss/font-awesome.min.css">
    <link rel="stylesheet" href="/thaisalecss/style.css">
    <link rel="stylesheet" href="/thaisalecss/waves.min.css">
    <link rel="stylesheet" href="/thaisalecss/jquery.mCustomScrollbar.min.css">
    <link rel="stylesheet" href="/thaisalecss/animate.css">
    <link rel="stylesheet" href="/thaisalecss/theme-indigo.css">
    <link rel="stylesheet" href="/thaisalecss/demo.css"> <!-- Demo only -->
    <!-- /Styles -->
</head>
   <style>
    body {
        padding-top: 60px;
    }
</style>
<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            <a class="navbar-brand" href="/"><span class="_2md"><font style="background-color: #000000">Thái Sale</font></span></a>
        </div>

        </div>
    </div>
</nav>
<body>
    <style>
        #fountainG {
            position: relative;
            width: 198px;
            height: 24px;
            margin: auto;
        }
        .fountainG {
            position: absolute;
            top: 0;
            background-color: rgb(245, 5, 217);
            width: 24px;
            height: 24px;
            animation-name: bounce_fountainG;
            -o-animation-name: bounce_fountainG;
            -ms-animation-name: bounce_fountainG;
            -webkit-animation-name: bounce_fountainG;
            -moz-animation-name: bounce_fountainG;
            animation-duration: 0.775s;
            -o-animation-duration: 0.775s;
            -ms-animation-duration: 0.775s;
            -webkit-animation-duration: 0.775s;
            -moz-animation-duration: 0.775s;
            animation-iteration-count: infinite;
            -o-animation-iteration-count: infinite;
            -ms-animation-iteration-count: infinite;
            -webkit-animation-iteration-count: infinite;
            -moz-animation-iteration-count: infinite;
            animation-direction: normal;
            -o-animation-direction: normal;
            -ms-animation-direction: normal;
            -webkit-animation-direction: normal;
            -moz-animation-direction: normal;
            transform: scale(.3);
            -o-transform: scale(.3);
            -ms-transform: scale(.3);
            -webkit-transform: scale(.3);
            -moz-transform: scale(.3);
            border-radius: 16px;
            -o-border-radius: 16px;
            -ms-border-radius: 16px;
            -webkit-border-radius: 16px;
            -moz-border-radius: 16px;
        }
        #fountainG_1 {
            left: 0;
            animation-delay: 0.316s;
            -o-animation-delay: 0.316s;
            -ms-animation-delay: 0.316s;
            -webkit-animation-delay: 0.316s;
            -moz-animation-delay: 0.316s;
        }
        #fountainG_2 {
            left: 25px;
            animation-delay: 0.3925s;
            -o-animation-delay: 0.3925s;
            -ms-animation-delay: 0.3925s;
            -webkit-animation-delay: 0.3925s;
            -moz-animation-delay: 0.3925s;
        }
        #fountainG_3 {
            left: 49px;
            animation-delay: 0.469s;
            -o-animation-delay: 0.469s;
            -ms-animation-delay: 0.469s;
            -webkit-animation-delay: 0.469s;
            -moz-animation-delay: 0.469s;
        }
        #fountainG_4 {
            left: 74px;
            animation-delay: 0.5455s;
            -o-animation-delay: 0.5455s;
            -ms-animation-delay: 0.5455s;
            -webkit-animation-delay: 0.5455s;
            -moz-animation-delay: 0.5455s;
        }
        #fountainG_5 {
            left: 99px;
            animation-delay: 0.622s;
            -o-animation-delay: 0.622s;
            -ms-animation-delay: 0.622s;
            -webkit-animation-delay: 0.622s;
            -moz-animation-delay: 0.622s;
        }
        #fountainG_6 {
            left: 124px;
            animation-delay: 0.6985s;
            -o-animation-delay: 0.6985s;
            -ms-animation-delay: 0.6985s;
            -webkit-animation-delay: 0.6985s;
            -moz-animation-delay: 0.6985s;
        }
        #fountainG_7 {
            left: 148px;
            animation-delay: 0.775s;
            -o-animation-delay: 0.775s;
            -ms-animation-delay: 0.775s;
            -webkit-animation-delay: 0.775s;
            -moz-animation-delay: 0.775s;
        }
        #fountainG_8 {
            left: 173px;
            animation-delay: 0.8615s;
            -o-animation-delay: 0.8615s;
            -ms-animation-delay: 0.8615s;
            -webkit-animation-delay: 0.8615s;
            -moz-animation-delay: 0.8615s;
        }
        @keyframes bounce_fountainG {
            0% {
                transform: scale(1);
                background-color: rgb(247, 5, 5);
            }
            100% {
                transform: scale(.3);
                background-color: rgb(92, 67, 92);
            }
        }
        @-o-keyframes bounce_fountainG {
            0% {
                -o-transform: scale(1);
                background-color: rgb(247, 5, 5);
            }
            100% {
                -o-transform: scale(.3);
                background-color: rgb(92, 67, 92);
            }
        }
        @-ms-keyframes bounce_fountainG {
            0% {
                -ms-transform: scale(1);
                background-color: rgb(247, 5, 5);
            }
            100% {
                -ms-transform: scale(.3);
                background-color: rgb(92, 67, 92);
            }
        }
        @-webkit-keyframes bounce_fountainG {
            0% {
                -webkit-transform: scale(1);
                background-color: rgb(247, 5, 5);
            }
            100% {
                -webkit-transform: scale(.3);
                background-color: rgb(92, 67, 92);
            }
        }
        @-moz-keyframes bounce_fountainG {
            0% {
                -moz-transform: scale(1);
                background-color: rgb(247, 5, 5);
            }
            100% {
                -moz-transform: scale(.3);
                background-color: rgb(92, 67, 92);
            }
        }
    </style>
   
 <!-- JavaScript -->
    <script src="assets/js/jquery-3.1.1.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/noti.js?_=1551197195"></script>
    <script>new WOW().init();</script>
   <!-- /./ -->
    <link rel="stylesheet" href="img/contact/bong.css">
    <script src="/TOOL/jquery-2.1.1.min.js"></script>
    <script src="/TOOL/main.js"></script>
    <script>b_sv = location.hostname;b_sv2 = location.hostname;</script>
    
<style>
.star{position:fixed;top:0;left:0;right:0;pointer-events:none;z-index:20}
.contentz{height:100%;position:absolute;overflow:hidden;z-index:1}
</style>
<style type="text/css">.jqstooltip { position: absolute;left: 0px;top: 0px;visibility: hidden;background: rgb(0, 0, 0) transparent;background-color: rgba(0,0,0,0.6);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000);-ms-filter: "progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000)";color: white;font: 10px arial, san serif;text-align: left;white-space: nowrap;padding: 5px;border: 1px solid white;box-sizing: content-box;z-index: 10000;}.jqsfield { color: white;font: 10px arial, san serif;text-align: left;}</style></head><body class="skin-black sidebar-mini sidebar-open          pace-running" style="height: auto;"><div class="pace pace-active"><div class="pace-progress" data-progress-text="95%" data-progress="95" style="transform: translate3d(95.3977%, 0px, 0px);">
  <div class="pace-progress-inner"></div>
</div>
<div class="pace-activity"></div></div><div class="contentz">
<canvas class="star" width="714" height="625"></canvas>
</div>
<script type="text/javascript">
//<![CDATA[
var canvas = $('canvas')[0];
var context = canvas.getContext('2d');

var Dots = [];
var ID = 0;
var colors = ['#FF9900', '#424242', '#BCBCBC', '#3299BB', '#B9D3B0', '#81BDA4', '#F88F79', '#F6AA93'];
var maximum = 100;

function Dot() {
  this.active = true;
  this.id = ID; ID++;
  
  this.diameter = 2 + Math.random() * 7;

  this.x = Math.round(Math.random() * canvas.width);
  this.y = Math.round(Math.random() * canvas.height);
  
  this.velocity = {
    x: (Math.random() < 0.5 ? -1 : 1) * Math.random() * 0.4,
    y: (Math.random() < 0.5 ? -1 : 1) * Math.random() * 0.4
  };

  this.alpha = 0.1;
  this.maxAlpha = this.diameter < 5 ? 0.3 : 0.8;
  this.hex = colors[Math.round(Math.random() * 7)];
  this.color = HexToRGBA(this.hex, this.alpha);
}

Dot.prototype = {
  Update: function() {
    if(this.alpha <= this.maxAlpha) {
      this.alpha += 0.005;
      this.color = HexToRGBA(this.hex, this.alpha);
    }

    this.x += this.velocity.x;
    this.y += this.velocity.y;

    if(this.x > canvas.width + 5 || this.x < 0 - 5 || this.y > canvas.height + 5 || this.y < 0 - 5) {
      this.active = false;
    }
  },

  Draw: function() {
    context.strokeStyle = this.color;
    context.fillStyle = this.color;
    context.save();
    context.beginPath();
    context.translate(this.x, this.y);
    context.moveTo(0, -this.diameter);

    for (var i = 0; i < 7; i++)
    {
      context.rotate(Math.PI / 7);
      context.lineTo(0, -(this.diameter / 2));
      context.rotate(Math.PI / 7);
      context.lineTo(0, -this.diameter);
    }

    if(this.id % 2 == 0) {
      context.stroke();
    } else {
      context.fill();
    }
    
    context.closePath();
    context.restore();
  }
}

function Update() {
  GenerateDots();

  Dots.forEach(function(Dot) {
    Dot.Update();
  });

  Dots = Dots.filter(function(Dot) {
    return Dot.active;
  });

  Render();
  requestAnimationFrame(Update);
}

function Render() {
  context.clearRect(0, 0, canvas.width, canvas.height);
  Dots.forEach(function(Dot) {
    Dot.Draw();
  });
}

function GenerateDots() {
  if(Dots.length < maximum) {
    for(var i = Dots.length; i < maximum; i++) {
      Dots.push(new Dot());
    }
  }

  return false;
}

function HexToRGBA(hex, alpha) {
  var red = parseInt((TrimHex(hex)).substring(0, 2), 16);
  var green = parseInt((TrimHex(hex)).substring(2, 4), 16);
  var blue = parseInt((TrimHex(hex)).substring(4, 6), 16);

  return 'rgba(' + red + ', ' + green + ', ' + blue + ', ' + alpha + ')';
}

function TrimHex(hex) {
  return (hex.charAt(0) == "#") ? hex.substring(1, 7) : hex;
}

function WindowSize(width, height) {
  if(width != null) { canvas.width = width; } else { canvas.width = window.innerWidth; }
  if(height != null) { canvas.height = height; } else { canvas.height = window.innerHeight; }
  
}

$(window).resize(function() {
  Dots = [];
  WindowSize();
});

WindowSize();
GenerateDots();
Update();
//]]>
</script>
<style>img[alt="www.000webhost.com"]{display:none;}</style>
<div align="center" style="z-index:9;visibility:visible;"></div><style>HTML,BODY{cursor: url("http://downloads.totallyfreecursors.com/cursor_files/hand.cur"), url("http://downloads.totallyfreecursors.com/thumbnails/hand.gif"), auto;}</style><style>
body {
        background-image: url("https://wikicachlam.com/wp-content/uploads/2018/03/mau-tim.jpg");
} 
 
</style> 
<body>
    <style>
        #fountainG {
            position: relative;
            width: 198px;
            height: 24px;
            margin: auto;
        }
        .fountainG {
            position: absolute;
            top: 0;
            background-color: rgb(245, 5, 217);
            width: 24px;
            height: 24px;
            animation-name: bounce_fountainG;
            -o-animation-name: bounce_fountainG;
            -ms-animation-name: bounce_fountainG;
            -webkit-animation-name: bounce_fountainG;
            -moz-animation-name: bounce_fountainG;
            animation-duration: 0.775s;
            -o-animation-duration: 0.775s;
            -ms-animation-duration: 0.775s;
            -webkit-animation-duration: 0.775s;
            -moz-animation-duration: 0.775s;
            animation-iteration-count: infinite;
            -o-animation-iteration-count: infinite;
            -ms-animation-iteration-count: infinite;
            -webkit-animation-iteration-count: infinite;
            -moz-animation-iteration-count: infinite;
            animation-direction: normal;
            -o-animation-direction: normal;
            -ms-animation-direction: normal;
            -webkit-animation-direction: normal;
            -moz-animation-direction: normal;
            transform: scale(.3);
            -o-transform: scale(.3);
            -ms-transform: scale(.3);
            -webkit-transform: scale(.3);
            -moz-transform: scale(.3);
            border-radius: 16px;
            -o-border-radius: 16px;
            -ms-border-radius: 16px;
            -webkit-border-radius: 16px;
            -moz-border-radius: 16px;
        }
        #fountainG_1 {
            left: 0;
            animation-delay: 0.316s;
            -o-animation-delay: 0.316s;
            -ms-animation-delay: 0.316s;
            -webkit-animation-delay: 0.316s;
            -moz-animation-delay: 0.316s;
        }
        #fountainG_2 {
            left: 25px;
            animation-delay: 0.3925s;
            -o-animation-delay: 0.3925s;
            -ms-animation-delay: 0.3925s;
            -webkit-animation-delay: 0.3925s;
            -moz-animation-delay: 0.3925s;
        }
        #fountainG_3 {
            left: 49px;
            animation-delay: 0.469s;
            -o-animation-delay: 0.469s;
            -ms-animation-delay: 0.469s;
            -webkit-animation-delay: 0.469s;
            -moz-animation-delay: 0.469s;
        }
        #fountainG_4 {
            left: 74px;
            animation-delay: 0.5455s;
            -o-animation-delay: 0.5455s;
            -ms-animation-delay: 0.5455s;
            -webkit-animation-delay: 0.5455s;
            -moz-animation-delay: 0.5455s;
        }
        #fountainG_5 {
            left: 99px;
            animation-delay: 0.622s;
            -o-animation-delay: 0.622s;
            -ms-animation-delay: 0.622s;
            -webkit-animation-delay: 0.622s;
            -moz-animation-delay: 0.622s;
        }
        #fountainG_6 {
            left: 124px;
            animation-delay: 0.6985s;
            -o-animation-delay: 0.6985s;
            -ms-animation-delay: 0.6985s;
            -webkit-animation-delay: 0.6985s;
            -moz-animation-delay: 0.6985s;
        }
        #fountainG_7 {
            left: 148px;
            animation-delay: 0.775s;
            -o-animation-delay: 0.775s;
            -ms-animation-delay: 0.775s;
            -webkit-animation-delay: 0.775s;
            -moz-animation-delay: 0.775s;
        }
        #fountainG_8 {
            left: 173px;
            animation-delay: 0.8615s;
            -o-animation-delay: 0.8615s;
            -ms-animation-delay: 0.8615s;
            -webkit-animation-delay: 0.8615s;
            -moz-animation-delay: 0.8615s;
        }
        @keyframes bounce_fountainG {
            0% {
                transform: scale(1);
                background-color: rgb(247, 5, 5);
            }
            100% {
                transform: scale(.3);
                background-color: rgb(92, 67, 92);
            }
        }
        @-o-keyframes bounce_fountainG {
            0% {
                -o-transform: scale(1);
                background-color: rgb(247, 5, 5);
            }
            100% {
                -o-transform: scale(.3);
                background-color: rgb(92, 67, 92);
            }
        }
        @-ms-keyframes bounce_fountainG {
            0% {
                -ms-transform: scale(1);
                background-color: rgb(247, 5, 5);
            }
            100% {
                -ms-transform: scale(.3);
                background-color: rgb(92, 67, 92);
            }
        }
        @-webkit-keyframes bounce_fountainG {
            0% {
                -webkit-transform: scale(1);
                background-color: rgb(247, 5, 5);
            }
            100% {
                -webkit-transform: scale(.3);
                background-color: rgb(92, 67, 92);
            }
        }
        @-moz-keyframes bounce_fountainG {
            0% {
                -moz-transform: scale(1);
                background-color: rgb(247, 5, 5);
            }
            100% {
                -moz-transform: scale(.3);
                background-color: rgb(92, 67, 92);
            }
        }
    </style>
    <style>
    #fountainG{
        position:relative;
        width:198px;
        height:24px;
        margin:auto;
    }

    .fountainG{
        position:absolute;
        top:0;
        background-color:rgb(245,5,217);
        width:24px;
        height:24px;
        animation-name:bounce_fountainG;
        -o-animation-name:bounce_fountainG;
        -ms-animation-name:bounce_fountainG;
        -webkit-animation-name:bounce_fountainG;
        -moz-animation-name:bounce_fountainG;
        animation-duration:0.775s;
        -o-animation-duration:0.775s;
        -ms-animation-duration:0.775s;
        -webkit-animation-duration:0.775s;
        -moz-animation-duration:0.775s;
        animation-iteration-count:infinite;
        -o-animation-iteration-count:infinite;
        -ms-animation-iteration-count:infinite;
        -webkit-animation-iteration-count:infinite;
        -moz-animation-iteration-count:infinite;
        animation-direction:normal;
        -o-animation-direction:normal;
        -ms-animation-direction:normal;
        -webkit-animation-direction:normal;
        -moz-animation-direction:normal;
        transform:scale(.3);
        -o-transform:scale(.3);
        -ms-transform:scale(.3);
        -webkit-transform:scale(.3);
        -moz-transform:scale(.3);
        border-radius:16px;
        -o-border-radius:16px;
        -ms-border-radius:16px;
        -webkit-border-radius:16px;
        -moz-border-radius:16px;
    }

    #fountainG_1{
        left:0;
        animation-delay:0.316s;
        -o-animation-delay:0.316s;
        -ms-animation-delay:0.316s;
        -webkit-animation-delay:0.316s;
        -moz-animation-delay:0.316s;
    }

    #fountainG_2{
        left:25px;
        animation-delay:0.3925s;
        -o-animation-delay:0.3925s;
        -ms-animation-delay:0.3925s;
        -webkit-animation-delay:0.3925s;
        -moz-animation-delay:0.3925s;
    }

    #fountainG_3{
        left:49px;
        animation-delay:0.469s;
        -o-animation-delay:0.469s;
        -ms-animation-delay:0.469s;
        -webkit-animation-delay:0.469s;
        -moz-animation-delay:0.469s;
    }

    #fountainG_4{
        left:74px;
        animation-delay:0.5455s;
        -o-animation-delay:0.5455s;
        -ms-animation-delay:0.5455s;
        -webkit-animation-delay:0.5455s;
        -moz-animation-delay:0.5455s;
    }

    #fountainG_5{
        left:99px;
        animation-delay:0.622s;
        -o-animation-delay:0.622s;
        -ms-animation-delay:0.622s;
        -webkit-animation-delay:0.622s;
        -moz-animation-delay:0.622s;
    }

    #fountainG_6{
        left:124px;
        animation-delay:0.6985s;
        -o-animation-delay:0.6985s;
        -ms-animation-delay:0.6985s;
        -webkit-animation-delay:0.6985s;
        -moz-animation-delay:0.6985s;
    }

    #fountainG_7{
        left:148px;
        animation-delay:0.775s;
        -o-animation-delay:0.775s;
        -ms-animation-delay:0.775s;
        -webkit-animation-delay:0.775s;
        -moz-animation-delay:0.775s;
    }

    #fountainG_8{
        left:173px;
        animation-delay:0.8615s;
        -o-animation-delay:0.8615s;
        -ms-animation-delay:0.8615s;
        -webkit-animation-delay:0.8615s;
        -moz-animation-delay:0.8615s;
    }



    @keyframes bounce_fountainG{
        0%{
            transform:scale(1);
            background-color:rgb(247,5,5);
        }

        100%{
            transform:scale(.3);
            background-color:rgb(92,67,92);
        }
    }

    @-o-keyframes bounce_fountainG{
        0%{
            -o-transform:scale(1);
            background-color:rgb(247,5,5);
        }

        100%{
            -o-transform:scale(.3);
            background-color:rgb(92,67,92);
        }
    }

    @-ms-keyframes bounce_fountainG{
        0%{
            -ms-transform:scale(1);
            background-color:rgb(247,5,5);
        }

        100%{
            -ms-transform:scale(.3);
            background-color:rgb(92,67,92);
        }
    }

    @-webkit-keyframes bounce_fountainG{
        0%{
            -webkit-transform:scale(1);
            background-color:rgb(247,5,5);
        }

        100%{
            -webkit-transform:scale(.3);
            background-color:rgb(92,67,92);
        }
    }

    @-moz-keyframes bounce_fountainG{
        0%{
            -moz-transform:scale(1);
            background-color:rgb(247,5,5);
        }

        100%{
            -moz-transform:scale(.3);
            background-color:rgb(92,67,92);
        }
    }
</style>
<script>
            function _Kunloc() {
                if (confirm('Nhấn OK để tới liên kết ADMIN') == true) {
                    window.location = 'https://www.facebook.com/SayHiThaiNe';
                } else {
                   return false;
                }
            }
    </script>
</head>
